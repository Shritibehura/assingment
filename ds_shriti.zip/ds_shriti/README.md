# Data Science Assignment – Web3 Trading Team

## Project Overview
This project analyzes the relationship between trader behavior and market sentiment using two datasets: the Bitcoin Fear & Greed Index and historical trader data from Hyperliquid.

## Folder Structure
```
ds_shriti/
├── notebook_1.ipynb
├── csv_files/
│   ├── fear_greed_index.csv
│   └── historical_data.csv
├── outputs/
│   └── (charts, graphs, etc.)
├── ds_report.pdf
└── README.md
```

## How to Use
1. Open `notebook_1.ipynb` in Google Colab.
2. Ensure the CSV files are in the `csv_files/` folder.
3. Run the notebook cells to perform data analysis and generate outputs.
4. Visual outputs will be saved in the `outputs/` folder.
5. Summarize your findings in `ds_report.pdf`.

## Requirements
- Python 3.x
- pandas
- matplotlib
- seaborn

All required packages are installed in the first cell of the notebook if running in Colab.

## Notes
- Share your Colab notebook as a view-only link.
- Mirror this structure in your GitHub repository. 